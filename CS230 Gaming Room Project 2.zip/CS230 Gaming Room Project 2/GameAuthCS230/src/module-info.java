module GameAuth {
}