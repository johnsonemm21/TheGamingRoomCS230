package com.gamingroom.gameauth.auth;

import io.dropwizard.auth.Authorizer;

public class GameAuthorizer implements Authorizer<GameUser> 
{
    @Override
    public boolean authorize(GameUser user, String role) {
    	
        // FIXME: Finish the authorize method based on BasicAuth Security Example
    	if (user == null || role == null) return false;
    	
    	String required = role.trim().toUpperCase();
        // assume GameUser exposes roles as a Set<String>
        for (String r : user.getRoles()) {
            if (required.equalsIgnoreCase(r)) return true;
            // ADMIN acts as superset of USER
            if ("ADMIN".equalsIgnoreCase(r) && "USER".equals(required)) return true;
        }
        return false;
    	
    }
}